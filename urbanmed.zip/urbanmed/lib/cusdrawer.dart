import 'package:flutter/material.dart';

class MyDrawer extends StatefulWidget {
  @override
  DrawerState createState() => DrawerState();
}

class DrawerState extends State<MyDrawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children:<Widget> [
          UserAccountsDrawerHeader(
            accountName: Text(
                "Customer"
            ),
            accountEmail: Text(
                "abc@gmail.com"
            ),
            onDetailsPressed: (){},
          ),

          ListTile(
            leading: Icon(Icons.home),
            onTap: (){},
            enabled: true,
            title: Text(
                "Home"
            ),
          ),
          ListTile(
            leading: Icon(Icons.account_box),
            onTap: (){},
            enabled: true,
            title: Text(
                "Your Account"
            ),
          ),
          ListTile(
            leading: Icon(Icons.local_grocery_store),
            onTap: (){},
            enabled: true,
            title: Text(
                "Your Orders"
            ),
          ),
          ListTile(
            leading: Icon(Icons.chat),
            onTap: (){},
            enabled: true,
            title: Text(
                "My Chat"
            ),
          ),
          ListTile(
            leading: Icon(Icons.location_on),
            onTap: (){},
            enabled: true,
            title: Text(
                "Pharmacy By Area"
            ),
          ),
          ListTile(
            leading: Icon(Icons.settings),
            onTap: (){},
            enabled: true,
            title: Text(
                "Settings"
            ),
          ),
          ListTile(
            leading: Icon(Icons.help),
            onTap: (){},
            enabled: true,
            title: Text(
                "Help"
            ),
          ),
        ],
      ),
    );
  }
}
