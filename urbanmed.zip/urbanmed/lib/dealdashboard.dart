import 'package:urbanmed/dealdrawer.dart';
import 'package:flutter/material.dart';

class Ddashboard extends StatefulWidget {
  @override
  Dashboard createState() => Dashboard();
}

class Dashboard extends State<Ddashboard> {

  Icon cusIcon= Icon(Icons.search);
  Widget cusSearchbar=Text("UrbanMed");

  Widget potrait(){
    return Center(
      child: Text(
        'Potrait',
      ),
    );
  }

  Widget landscape(){
    return Center(
      child: Text(
        'Landscape',
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        actions: <Widget>[
          //InkWell(   if want to give space between search and dots.
          //child: SizedBox(
          //width: 100.0,
          //child: Icon(Icons.search),
          //),
          //),
          IconButton(
            onPressed: (){
              setState(() {
                if(this.cusIcon.icon==Icons.search)
                {
                  this.cusIcon=Icon(Icons.cancel);
                  this.cusSearchbar=Container(
                    width: MediaQuery.of(context).size.width/1.2,
                    height: 45,
                    margin: EdgeInsets.only(top: 15),
                    padding: EdgeInsets.only(
                        top: 4,left: 16, right: 16, bottom: 4
                    ),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                            Radius.circular(50)
                        ),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              blurRadius: 20
                          )
                        ]
                    ),
                    child: TextField(
                      textInputAction: TextInputAction.go,
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Hey, Searching Something????"
                      ),
                      style: TextStyle(
                        fontSize: 16.0,
                        color: Colors.white,
                      ),
                    ),
                  );
                }
                else{
                  this.cusIcon= Icon(Icons.search);
                  this.cusSearchbar=Text("UrbanMed");
                }
              });
            },
            icon: cusIcon,
          ),
          IconButton(
            onPressed: (){},
            icon: Icon(Icons.more_vert),
          ),
        ],
        title: cusSearchbar,
      ),
      drawer: Dealdrawer(),
      floatingActionButton: IconButton(
          icon: Icon(Icons.message),
          onPressed: (){}
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      bottomNavigationBar: BottomAppBar(
          child: Row(
            children: <Widget>[
              Expanded(
                child: SizedBox(
                  height:60.0,
                  child:InkWell(
                    onTap: (){},
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(Icons.group),
                        Text(
                          'Customers',
                        )
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: SizedBox(
                  height:60.0,
                  child:InkWell(
                    onTap: (){},
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(Icons.card_travel),
                        Text(
                          'Your Medicine Data',
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ],
          )
      ),
      body:OrientationBuilder(
        builder: (context, orientation){
          if(orientation == Orientation.portrait){
            return potrait();
          }
          else{
            return landscape();
          }
        },
      ),
      /*Row(
        children: <Widget>[
          Container(
            //height: 300.0,
            width: MediaQuery.of(context).size.width*0.5,
            decoration: BoxDecoration(
              color: Colors.red,
            ),
          ),
          Container(
            //height: 300.0,
            width: MediaQuery.of(context).size.width*0.5,
            decoration: BoxDecoration(
              color: Colors.blue,
          ),
          ),
        ],
      )*/

      /*Center(
        child: Text(
          'Splash \n Screen',
          style: TextStyle(
            fontSize: 25.0,
            fontFamily: 'Times New Roman',
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
      ),*/
    );

    /*FutureBuilder(
        future: DefaultAssetBundle.of(context).loadString("asset/data.json"),
        builder: (context,snapshot) {
          var mydata = json.decode(snapshot.data.toString());
          if (mydata == null) {
            return Center(
              child: Text(
                'Loading',
              ),
            );
          }
          else {
            return Center(
              child: Text(
                mydata[1]["name"],
                style: TextStyle(
                  fontSize: 25.0
                ),
              ),
            );
          }
        },
      ),*/
  }
}

