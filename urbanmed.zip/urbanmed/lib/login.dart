import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:urbanmed/cusregister.dart';
import 'package:urbanmed/dealdashboard.dart';
import 'package:urbanmed/dealregister.dart';
import 'package:urbanmed/cusdashboard.dart';

import 'geolocator.dart';

class Login extends StatefulWidget {
  @override
  Log createState() => Log();
}

class Log extends State<Login> with TickerProviderStateMixin {

  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  GlobalKey<FormState> formkey1 = GlobalKey<FormState>();
  GlobalKey<FormState> formkey2 = GlobalKey<FormState>();
  GlobalKey<FormState> formkey3 = GlobalKey<FormState>();

  // ignore: non_constant_identifier_names
  Widget Login(){
    return Container(
      child:Padding(
        padding: const EdgeInsets.only(top:20.0),
        child: Column(
          children: <Widget>[
            new Container(
              //padding:EdgeInsets.only(left: 20.0,right: 20.0,top: 20.0),
              width: MediaQuery.of(context).size.width/1.2,
              height: 45,
              margin: EdgeInsets.only(top: 15),
              padding: EdgeInsets.only(
                  top: 3,left: 16, right: 16, bottom: 3
              ),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(
                      Radius.circular(50)
                  ),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20
                    )
                  ]
              ),
              child: Form(
                autovalidate: true,
                key:formkey,
                child: TextFormField(
                  decoration: InputDecoration(
                    //labelText: "UserName",
                    border: InputBorder.none,
                    icon: Icon(Icons.supervised_user_circle,
                      color: Colors.grey,
                    ),
                    hintText: "UserName",
                  ),
                  validator: MultiValidator([
                    RequiredValidator(errorText: "Required"),
                  ]),
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width/1.2,
              height: 45,
              margin: EdgeInsets.only(top: 15),
              padding: EdgeInsets.only(
                  top: 3,left: 16, right: 16, bottom: 3
              ),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(
                      Radius.circular(50)
                  ),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20
                    )
                  ]
              ),
              child: Form(
                  autovalidate: true,
                  key: formkey1,
                  child: TextFormField(
                      decoration: new InputDecoration(
                        // labelText: 'Password',
                        border: InputBorder.none,
                        icon: Icon(Icons.lock_outline,
                          color: Colors.grey,
                        ),
                        hintText:'Password',
                      ),
                      validator: (val){
                        if(val.isEmpty)
                        {
                          return "Required";
                        }else if(val.length < 6)
                        {
                          return "Atleast 6 chars required";
                        }
                        else
                        {
                          return null;
                        }
                      }
                    //obscureText: true,
                  )
              ),
            ),
            FlatButton(
              padding: EdgeInsets.only(right: 0.0,left: 200.0,bottom: 20.0),
              child: new Text('Forgot Password?',
                style: TextStyle(
                  color: Colors.black45,
                ),
              ),
              onPressed: () {},
            ),
            /*RaisedButton(
              elevation: 10.0,
              child: new Text('Login'),
              onPressed: () {},
            ),*/
            Container(
              height: 45,
              width: MediaQuery.of(context).size.width/1.2,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFFff4081),
                      Color(0xFFf5851f)
                    ],
                  ),
                  borderRadius: BorderRadius.all(
                      Radius.circular(50)
                  )
              ),
              child: MaterialButton(onPressed: () {Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) =>  Cusboard(),
              ));
              },
                minWidth: MediaQuery.of(context).size.width,
                child: Text('login'.toUpperCase(),
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold
                  ),
                ),
              ),
            ),
            FlatButton(
                child: new Text("Dont have an account? Register here.",
                  style: TextStyle(
                    color: Colors.black45,
                  ),
                ),
                onPressed: () {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (context) => Cregister(),
                  ));
                }
            ),
          ],
        ),
      ),
    );
  }

  Widget login1(){
    return Container(
      child:Padding(
        padding: const EdgeInsets.only(top:20.0),
        child:Column(
          children: <Widget>[
            new Container(
              //padding:EdgeInsets.only(left: 20.0,right: 20.0,top: 20.0),
              width: MediaQuery.of(context).size.width/1.2,
              height: 45,
              margin: EdgeInsets.only(top: 15),
              padding: EdgeInsets.only(
                  top: 3,left: 16, right: 16, bottom: 3
              ),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(
                      Radius.circular(50)
                  ),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20
                    )
                  ]
              ),
              child: Form(
                autovalidate: true,
                key: formkey2,
                child: TextFormField(
                  decoration: InputDecoration(
                    //labelText: "UserName",
                    border: InputBorder.none,
                    icon: Icon(Icons.supervised_user_circle,
                      color: Colors.grey,
                    ),
                    hintText: "UserName",
                  ),
                  validator: MultiValidator([
                    RequiredValidator(errorText: "Required"),
                  ]),
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width/1.2,
              height: 45,
              margin: EdgeInsets.only(top: 15),
              padding: EdgeInsets.only(
                  top: 3,left: 16, right: 16, bottom: 3
              ),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(
                      Radius.circular(50)
                  ),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black12,
                        blurRadius: 20
                    )
                  ]
              ),
              child: Form(
                autovalidate: true,
                key: formkey3,
                child: TextFormField(
                  decoration: new InputDecoration(
                    // labelText: 'Password',
                    border: InputBorder.none,
                    icon: Icon(Icons.lock_outline,
                      color: Colors.grey,
                    ),
                    hintText:'Password',
                  ),
                  validator:MultiValidator([
                    RequiredValidator(errorText: "Required"),
                    MinLengthValidator(6, errorText:"More than 6 char required"),
                  ]),
                ),
              ),
            ),
            FlatButton(
              padding: EdgeInsets.only(right: 0.0,left: 200.0,bottom: 20.0),
              child:
              Text(
                'Forgot Password?',
                style: TextStyle(
                  color: Colors.black45,
                ),
              ),
              onPressed: () {},
            ),

            Container(
              height: 45,
              width: MediaQuery.of(context).size.width/1.2,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFFff4081),
                      Color(0xFFf5851f)
                    ],
                  ),
                  borderRadius: BorderRadius.all(
                      Radius.circular(50)
                  )
              ),
              child: MaterialButton(onPressed: () {Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) => Ddashboard(),
              ));},
                minWidth: MediaQuery.of(context).size.width,
                child: Text('login'.toUpperCase(),
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold
                  ),
                ),
              ),
            ),

            FlatButton(
                child: new Text("Don't have an account? Register here.",
                  style: TextStyle(
                    color: Colors.black45,
                  ),
                ),
                onPressed: () {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (context) => Dregister(),
                  ));
                }
            ),
          ],
        ),
      ),
    );
  }

  TabController tb;

  @override
  void initState(){
    tb=TabController(
      length: 2,
      vsync:this,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 100.0,
        centerTitle: true,
        bottom: TabBar(
          tabs: <Widget>[
            Text(
              'Customer',
            ),
            Text(
              'Dealer',
            ),
          ],
          labelStyle: TextStyle(
            fontSize: 20.0,
            fontWeight: FontWeight.w600,
          ),
          labelPadding: EdgeInsets.only(bottom: 10.0),
          unselectedLabelColor: Colors.white60,
          controller: tb,
        ),
      ),
      body: TabBarView(
        children:<Widget>[
          Login(),
          login1()
        ],
        controller: tb,
      ),
    );
  }
}

