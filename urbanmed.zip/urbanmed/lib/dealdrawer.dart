import 'package:flutter/material.dart';
import 'package:urbanmed/dealdashboard.dart';
import 'package:urbanmed/productdetails.dart';
import 'package:urbanmed/shopdetails.dart';

class Dealdrawer extends StatefulWidget {
  @override
  Ddrawer createState() => Ddrawer();
}

class Ddrawer extends State<Dealdrawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children:<Widget> [
          UserAccountsDrawerHeader(
            accountName: Text(
                "Dealer"
            ),
            accountEmail: Text(
                "abc@gmail.com"
            ),
            onDetailsPressed: (){},
          ),

          ListTile(
            leading: Icon(Icons.home),
            title: Text('Home'
            ),
            onTap: (){
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) => Ddashboard(),));
            },
            enabled: true,
          ),
          ListTile(
            leading: Icon(Icons.description),
            onTap: (){Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (context) => Sdetail(),
            ));
            },
            enabled: true,
            title: Text(
                "Your Shop Details"
            ),
          ),
          ListTile(
            leading: Icon(Icons.add_box),
            onTap: (){Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (context) => Pdetails(),
            ));
            },
            enabled: true,
            title: Text(
                "Your Product Details"
            ),
          ),
          ListTile(
            leading: Icon(Icons.chat),
            onTap: (){},
            enabled: true,
            title: Text(
                "Chat"
            ),
          ),
          ListTile(
            leading: Icon(Icons.local_offer),
            onTap: (){},
            enabled: true,
            title: Text(
                "Your Offers"
            ),
          ),
          ListTile(
            leading: Icon(Icons.settings),
            onTap: (){},
            enabled: true,
            title: Text(
                "Settings"
            ),
          ),
          ListTile(
            leading: Icon(Icons.help),
            onTap: (){},
            enabled: true,
            title: Text(
                "Help"
            ),
          ),
        ],
      ),
    );
  }
}